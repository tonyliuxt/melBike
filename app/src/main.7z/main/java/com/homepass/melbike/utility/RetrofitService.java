package com.homepass.melbike.utility;

import com.homepass.melbike.Constants;
import com.homepass.melbike.entitiy.BikeSite;
import com.homepass.melbike.interfaces.IEndpoints;
import com.homepass.melbike.interfaces.JsonStringConverterFactory;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.Response;
/**
 * Created by Xintian on 2016/12/10.
 */

public class RetrofitService {
    interface Service {
        @GET("/filter")
        Call<ResponseBody> example();
    }

    public static void RawDataBack() {
        try {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.API_BASE_URL)
                    .addConverterFactory(new JsonStringConverterFactory(GsonConverterFactory.create()))
                    .build();
            IEndpoints service = retrofit.create(IEndpoints.class);

            Call<ResponseBody> call = service.bikesites2();
            Response<ResponseBody> response = call.execute();

            System.out.println("--== bikesite:"+ response.body().toString());
//            List<BikeSite> bikeSiteList = service.bikesites().execute().body();
//            // TODO handle user response...
//
//            if (bikeSiteList != null) {
//                for (BikeSite bikesite : bikeSiteList) {
//                    System.out.println("-- bikesite:" + bikesite.getFeaturename());
//                }
//            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
