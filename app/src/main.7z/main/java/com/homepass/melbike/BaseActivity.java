package com.homepass.melbike;

import android.support.v4.app.FragmentActivity;

/**
 * Created by Xintian on 2016/12/7.
 */

public class BaseActivity extends FragmentActivity {
}
