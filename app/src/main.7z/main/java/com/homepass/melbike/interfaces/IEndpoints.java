package com.homepass.melbike.interfaces;

import com.homepass.melbike.entitiy.BikeSite;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
/**
 * Created by Xintian on 2016/12/7.
 */

public interface IEndpoints {
//    @GET("/resource/qnjw-wgaj.json")
//    Call<List<BikeSite>> bikesites();

    @GET("/resource/qnjw-wgaj.json")
    Call<ResponseBody> bikesites2();
}
