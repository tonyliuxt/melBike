package com.homepass.melbike;

/**
 * Created by Xintian on 2016/12/7.
 */

public class Constants {
    public static final String API_BASE_URL = "https://data.melbourne.vic.gov.au";
}
